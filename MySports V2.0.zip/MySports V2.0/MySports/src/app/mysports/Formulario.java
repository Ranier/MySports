package app.mysports;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;
import app.mysports.dao.AtletaDAO;
import app.mysports.modelo.Atleta;

public class Formulario extends Activity {
	
	private FormularioHelper helper;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.formulario);
		
		helper = new FormularioHelper(this);
		
		
		
	    Button salvar = (Button) findViewById(R.id.salvar);
		Button cancelar = (Button) findViewById(R.id.cancelar);
		
		cancelar.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent troca = new Intent(Formulario.this, Login.class);
		        startActivity(troca);
			}
		});
		
		salvar.setOnClickListener(new OnClickListener(){
			
			public void onClick(View v){
				
				Atleta atleta = helper.pegaAtletaFormulario();
				
				AtletaDAO dao = new AtletaDAO(Formulario.this);
				dao.salva(atleta);
				dao.close();
				Toast.makeText(Formulario.this, "CADASTRO EFETUADO COM SUCESSO!", Toast.LENGTH_LONG).show();
				Intent irParaPrincipal = new Intent(Formulario.this,MysportsActivity.class); 
				startActivity(irParaPrincipal);
				finish();
					
			}
			
			
		});
		
	}

}
