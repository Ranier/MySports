package app.mysports.dao;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
//import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
//import android.sax.StartElementListener;
//import android.widget.EditText;
import android.widget.Toast;
//import app.mysports.Formulario;
//import app.mysports.Login;
//import app.mysports.MysportsActivity;
import app.mysports.modelo.Atleta;

public class AtletaDAO extends SQLiteOpenHelper{
	
	private static final String DATABASE = "Mysports";
	private static final int VERSAO = 5;

	public AtletaDAO(Context context) {
		super(context, DATABASE, null, VERSAO);
		
	}
	
	public void valida(Atleta atleta){
		
		
	}

	
	public void salva(Atleta atleta) {
		
		ContentValues values = new ContentValues();
		
		
		values.put("nome", atleta.getNome());
		values.put("idade", atleta.getIdade());
		values.put("email", atleta.getEmail());
		values.put("peso", atleta.getPeso());
		values.put("senha", atleta.getSenha());
		
		getWritableDatabase().insert("Atletas", null, values);
		
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		
		String ddl = "CREATE TABLE Atletas (id PRIMARY KEY ," +
				" nome TEXT UNIQUE NOT NULL , idade TEXT, email TEXT, peso TEXT, senha TEXT );";
	db.execSQL(ddl);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		String ddl = "DROP TABLE IF EXISTS Atletas";
		db.execSQL(ddl);
		this.onCreate(db);
	}
	
	
	
	
	
	
	
	public List<Atleta> ValidaUsuario() {
		
		String[] colunas = {"id","nome","senha"};
		Cursor cursor = getReadableDatabase().query("Atletas", colunas, null, null, null, null, null);
		ArrayList<Atleta> atletas = new ArrayList<Atleta>();
		while (cursor.moveToNext()) {
			Atleta atleta = new Atleta();
			if (atleta.getNome().equals("nome") && atleta.getSenha().equals("senha")) {
				System.out.println("Atleta" + atleta.getNome().toString());
			
			}else{
				
				Toast.makeText(null, "Senha Incorreta!", Toast.LENGTH_SHORT).show();
			}
		}
		return atletas;
	}

	public List<Atleta> getLista() {
		String[] colunas = {"id","nome","idade","email","peso","senha"};
		Cursor cursor = getWritableDatabase().query("Atletas", colunas, null, null, null, null, null);
		
		ArrayList<Atleta> atletas = new ArrayList<Atleta>();
		
		while (cursor.moveToNext()) {
		
		Atleta atleta = new Atleta();
		
		atleta.setId(cursor.getLong(0));
		atleta.setNome(cursor.getString(1));
		atleta.setIdade(cursor.getString(2));
		atleta.setEmail(cursor.getString(3));
		atleta.setPeso(cursor.getString(4));
		atleta.setSenha(cursor.getString(5));
		
		atletas.add(atleta);
		}
		return atletas;
	}

}
