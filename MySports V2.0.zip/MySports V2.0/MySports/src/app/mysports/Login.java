package app.mysports;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends Activity{
	
	private FormularioHelper helper;
	private EditText nomenovo;
	private EditText senhanova;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		
		Button criarcadastro = (Button) findViewById(R.id.cadastrar);
		Button entrar = (Button) findViewById(R.id.entrar);
		
		nomenovo = (EditText) findViewById(R.id.nome);
		senhanova = (EditText) findViewById(R.id.senha);
		
		 
		helper = new FormularioHelper(this);

			criarcadastro.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent irParaCadastro = new Intent(Login.this,Formulario.class); 
					startActivity(irParaCadastro);	
				}
			});
				
			entrar.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					
					Toast.makeText(Login.this, "Login efetuado com sucesso!", Toast.LENGTH_LONG).show();
					Intent irParaPrinc = new Intent(Login.this,Atividade.class); 
					startActivity(irParaPrinc);	
				}			
			});
	}

	@Override
	protected void onPause() {
		super.onPause();
		finish();
	}
	

}