package app.mysports;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class Atividade extends Activity{

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.atividade);
		
			Button cancelar = (Button) findViewById(R.id.cancelar);
			Button iniciar = (Button) findViewById(R.id.iniciar);
						
			cancelar.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					
					finish();
				}
			});
			iniciar.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					
					Toast.makeText(Atividade.this, "ATIVIDADE INICIADA COM SUCESSO!", Toast.LENGTH_LONG).show();
				}
			});
	 }
	}
