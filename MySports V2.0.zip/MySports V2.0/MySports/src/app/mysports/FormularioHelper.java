package app.mysports;

import android.widget.EditText;
import app.mysports.modelo.Atleta;

public class FormularioHelper {
	
	private EditText editNome;
	private EditText editIdade;
	private EditText editEmail;
	private EditText editPeso;
	private EditText editSenha;
	
	
	public FormularioHelper(Formulario formulario) {
		editNome = (EditText) formulario.findViewById(R.id.nome);
		editIdade = (EditText) formulario.findViewById(R.id.idade);
		editEmail = (EditText) formulario.findViewById(R.id.email);
		editPeso = (EditText) formulario.findViewById(R.id.peso);
		editSenha = (EditText) formulario.findViewById(R.id.senha);
	}
	
	public FormularioHelper(Login login) {
		editNome  = (EditText) login.findViewById(R.id.nome);
		
	}
	
	
	public Atleta pegaAtletaFormulario() {
		Atleta atleta = new Atleta();
		
		atleta.setNome(editNome.getText().toString());
		atleta.setIdade(editIdade.getText().toString());
		atleta.setEmail(editEmail.getText().toString());
		atleta.setPeso(editPeso.getText().toString());
		atleta.setSenha(editSenha.getText().toString());
		return atleta;		
	}
	
     public Login pegaLogin() {
		Login login = new Login();
		
		
		return login;		
	}
	
}
