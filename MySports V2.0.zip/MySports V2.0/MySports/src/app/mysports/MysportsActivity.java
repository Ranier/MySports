package app.mysports;


import java.util.List;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import app.mysports.dao.AtletaDAO;
import app.mysports.modelo.Atleta;

public class MysportsActivity extends Activity {

	private ListView lista;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       
        setContentView(R.layout.activity_mysports);
        
        Intent irParaLogin = new Intent(this,Login.class); 
		startActivity(irParaLogin);
       
        lista= (ListView) findViewById(R.id.lista); 
        
        lista.setOnItemClickListener(new OnItemClickListener(){
        	
   			@Override
			public void onItemClick(AdapterView<?> adapter, View view,
					int posicao, long id) {
   				Intent irAtividade = new Intent(MysportsActivity.this,Atividade.class); 
   				startActivity(irAtividade);
				Toast.makeText(MysportsActivity.this, "Iniciando Atividade de :\n" + adapter.getItemAtPosition(posicao) , Toast.LENGTH_SHORT).show();
			}	
    });  
   }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	
    	MenuInflater inflater = getMenuInflater();
    	inflater.inflate(R.menu.mysports, menu);
    	
    	return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
		
    	int itemclicado = item.getItemId();
    	
    	switch (itemclicado) {
		case R.id.novo:
			Intent irParaFormulario = new Intent(this,Formulario.class); 
			startActivity(irParaFormulario);
			break;
		
		case R.id.login:
			Intent irPara = new Intent(this,Login.class); 
			startActivity(irPara);
			break;
			
		case R.id.atividade:
			Intent irAtividade = new Intent(this,Atividade.class); 
			startActivity(irAtividade);
			break;
			
		case R.id.sobre:
			Toast.makeText(MysportsActivity.this, "Aplica��o: MySportes \nVers�o: 1.0 " +
					"\nData de publica��o 27/10/2014 " +
					"\nDesenvolvedores: " +
					"\nRanier William " +
					"\nClodoaldo " +
					"\nAnt�nio Celestino" , Toast.LENGTH_LONG).show();
						
		default:
			break;
		}
    	
    	
    	return super.onOptionsItemSelected(item); 
    	
    }
    
    @Override
    protected void onResume() {
    	super.onResume();
    	AtletaDAO dao = new AtletaDAO(this);        
        List<Atleta> atleta = dao.getLista();
        dao.close();
        
              
        int layout = android.R.layout.select_dialog_item;
        ArrayAdapter<Atleta> adapter = new ArrayAdapter<Atleta>(this, layout,atleta);
        
        lista.setAdapter(adapter);
    }

}