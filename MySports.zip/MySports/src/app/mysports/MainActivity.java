package app.mysports;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity
{
    
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        
        
        
        EditText nome = (EditText) findViewById(R.id.nome);
        EditText idade = (EditText) findViewById(R.id.idade);
        Button gravar = (Button) findViewById(R.id.gravar);
        Button cancelar = (Button) findViewById(R.id.cancelar);
        
        gravar.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "XXXXXLONGAAAAAAAAAAA", Toast.LENGTH_LONG).show();
                Log.i("TAG", "CLICOU!!!");
                
                
            }
        });
        
    }
}
