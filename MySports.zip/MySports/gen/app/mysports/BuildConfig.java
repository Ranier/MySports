/** Automatically generated file. DO NOT MODIFY */
package app.mysports;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}